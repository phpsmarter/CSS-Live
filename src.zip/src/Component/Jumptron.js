import React from 'react';
import { Jumbotron, Button } from 'reactstrap';

const BigScreen = (props) => {
  return (
    <div>
      <Jumbotron>
        
      </Jumbotron>
    </div>
  );
};

export {BigScreen};